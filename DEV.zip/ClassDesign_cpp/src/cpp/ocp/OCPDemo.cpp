#include <iostream>
#include <cmath>
#include <memory>

// 추상 클래스: 도형의 기본 설계
class Shape {
public:
    virtual ~Shape() = default;
    virtual double calculateArea() = 0;
};

// 사각형 클래스
class Rectangle : public Shape {
private:
    double width;
    double height;

public:
    Rectangle(double width, double height)
        : width(width), height(height) {}

    double calculateArea() override {
        return width * height;
    }
};

// 원 클래스
class Circle : public Shape {
private:
    double radius;

public:
    Circle(double radius) : radius(radius) {}

    double calculateArea() override {
        return M_PI * radius * radius;
    }
};

// 삼각형 클래스
class Triangle : public Shape {
private:
    double base;
    double height;

public:
    Triangle(double base, double height)
        : base(base), height(height) {}

    double calculateArea() override {
        return 0.5 * base * height;
    }
};

// 메인 함수 - OCP 데모
int main() {
    std::unique_ptr<Shape> rectangle = std::make_unique<Rectangle>(5, 10); // 사각형
    std::unique_ptr<Shape> circle = std::make_unique<Circle>(7);           // 원
    std::unique_ptr<Shape> triangle = std::make_unique<Triangle>(6, 8);    // 삼각형

    std::cout << "사각형 넓이: " << rectangle->calculateArea() << std::endl;
    std::cout << "원 넓이: " << circle->calculateArea() << std::endl;
    std::cout << "삼각형 넓이: " << triangle->calculateArea() << std::endl;

    return 0;
}
