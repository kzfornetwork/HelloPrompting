#include <iostream>
#include <string>

enum class Maker {
    FENDER,
    GIBSON,
    MARTIN
};

enum class Wood {
    MAHOGANY,
    MAPLE,
    ALDER,
    ROSEWOOD
};

class Guitar {
private:
    std::string serialNumber;
    double price;
    Maker maker;
    std::string model;
    Wood topWood;
    Wood backWood;
    int stringNum;

public:
    Guitar(const std::string& serialNumber, double price, Maker maker,
           const std::string& model, Wood topWood, Wood backWood, int stringNum)
        : serialNumber(serialNumber), price(price), maker(maker),
          model(model), topWood(topWood), backWood(backWood), stringNum(stringNum) {}

    std::string getSerialNumber() const { return serialNumber; }
    double getPrice() const { return price; }
    Maker getBuilder() const { return maker; }
    std::string getType() const { return model; }
    Wood getBackWood() const { return backWood; }
    Wood getTopWood() const { return topWood; }
    int getStringNum() const { return stringNum; }
    std::string getModel() const { return model; }
};

std::string makerToString(Maker maker) {
    switch (maker) {
        case Maker::FENDER: return "FENDER";
        case Maker::GIBSON: return "GIBSON";
        case Maker::MARTIN: return "MARTIN";
        default: return "UNKNOWN";
    }
}

std::string woodToString(Wood wood) {
    switch (wood) {
        case Wood::MAHOGANY: return "MAHOGANY";
        case Wood::MAPLE: return "MAPLE";
        case Wood::ALDER: return "ALDER";
        case Wood::ROSEWOOD: return "ROSEWOOD";
        default: return "UNKNOWN";
    }
}

int main() {
    Guitar guitar("SN-001", 1500.0, Maker::FENDER,
                  "Stratocaster", Wood::MAPLE, Wood::ALDER, 6);

    std::cout << "Serial Number: " << guitar.getSerialNumber() << '\n';
    std::cout << "Price: " << guitar.getPrice() << '\n';
    std::cout << "Maker: " << makerToString(guitar.getBuilder()) << '\n';
    std::cout << "Model: " << guitar.getModel() << '\n';
    std::cout << "Top Wood: " << woodToString(guitar.getTopWood()) << '\n';
    std::cout << "Back Wood: " << woodToString(guitar.getBackWood()) << '\n';
    std::cout << "String Number: " << guitar.getStringNum() << '\n';

    return 0;
}