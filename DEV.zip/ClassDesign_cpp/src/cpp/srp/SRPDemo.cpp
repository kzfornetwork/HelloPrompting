#include <iostream>
#include <string>

// 1. 열거형 데이터
enum class Maker {
    FENDER,
    GIBSON
};

enum class Wood {
    MAHOGANY,
    MAPLE
};

// enum 출력용 함수
std::string toString(Maker maker) {
    switch (maker) {
        case Maker::FENDER: return "FENDER";
        case Maker::GIBSON: return "GIBSON";
        default: return "UNKNOWN";
    }
}

std::string toString(Wood wood) {
    switch (wood) {
        case Wood::MAHOGANY: return "MAHOGANY";
        case Wood::MAPLE: return "MAPLE";
        default: return "UNKNOWN";
    }
}

// 2. 사양 클래스: 오직 기타의 물리적 특징만 담당
class GuitarSpec {
private:
    Maker maker;
    std::string model;
    Wood topWood;
    Wood backWood;
    int stringNum;

public:
    GuitarSpec(Maker maker, const std::string& model, Wood topWood, Wood backWood, int stringNum)
        : maker(maker), model(model), topWood(topWood), backWood(backWood), stringNum(stringNum) {}

    Maker getMaker() const { return maker; }
    std::string getModel() const { return model; }
    Wood getTopWood() const { return topWood; }
    Wood getBackWood() const { return backWood; }
    int getStringNum() const { return stringNum; }
};

// 3. 기타 클래스: 개별 악기의 정보와 변하는 상태(가격) 담당
class Guitar {
private:
    std::string serialNumber;
    double price;
    GuitarSpec spec;

public:
    Guitar(const std::string& serialNumber, double price, const GuitarSpec& spec)
        : serialNumber(serialNumber), price(price), spec(spec) {}

    std::string getSerialNumber() const { return serialNumber; }
    double getPrice() const { return price; }
    void setPrice(double newPrice) { price = newPrice; }
    const GuitarSpec& getSpec() const { return spec; }
};

// 4. 실행 함수
int main() {
    // 사양 객체 생성
    GuitarSpec stratSpec(Maker::FENDER, "Stratocaster", Wood::MAPLE, Wood::MAHOGANY, 6);

    // 개별 기타 객체 생성
    Guitar myGuitar("V12345", 1500.0, stratSpec);

    std::cout << "--- 기타 정보 ---" << std::endl;
    std::cout << "시리얼 번호: " << myGuitar.getSerialNumber() << std::endl;
    std::cout << "제조사: " << toString(myGuitar.getSpec().getMaker()) << std::endl;
    std::cout << "모델명: " << myGuitar.getSpec().getModel() << std::endl;
    std::cout << "상판 목재: " << toString(myGuitar.getSpec().getTopWood()) << std::endl;
    std::cout << "후판 목재: " << toString(myGuitar.getSpec().getBackWood()) << std::endl;
    std::cout << "줄 수: " << myGuitar.getSpec().getStringNum() << std::endl;
    std::cout << "현재 가격: $" << myGuitar.getPrice() << std::endl;

    return 0;
}