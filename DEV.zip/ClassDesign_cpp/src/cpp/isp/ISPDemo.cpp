#include <iostream>
#include <memory>

// 기본 동물 행동 인터페이스
class BasicAnimalActions {
public:
    virtual ~BasicAnimalActions() = default;
    virtual void eat() = 0;
    virtual void sleep() = 0;
};

// 날 수 있는 동물을 위한 인터페이스
class FlyingAnimalActions {
public:
    virtual ~FlyingAnimalActions() = default;
    virtual void fly() = 0;
};

// 수영할 수 있는 동물을 위한 인터페이스
class SwimmingAnimalActions {
public:
    virtual ~SwimmingAnimalActions() = default;
    virtual void swim() = 0;
};

// 새 클래스 (기본 행동 + 날기 구현)
class Bird : public BasicAnimalActions, public FlyingAnimalActions {
public:
    void eat() override {
        std::cout << "새가 먹이를 먹고 있습니다." << std::endl;
    }

    void sleep() override {
        std::cout << "새가 잠을 자고 있습니다." << std::endl;
    }

    void fly() override {
        std::cout << "새가 날고 있습니다." << std::endl;
    }
};

// 물고기 클래스 (기본 행동 + 수영 구현)
class Fish : public BasicAnimalActions, public SwimmingAnimalActions {
public:
    void eat() override {
        std::cout << "물고기가 먹이를 먹고 있습니다." << std::endl;
    }

    void sleep() override {
        std::cout << "물고기가 잠을 자고 있습니다." << std::endl;
    }

    void swim() override {
        std::cout << "물고기가 수영하고 있습니다." << std::endl;
    }
};

// 개 클래스 (기본 행동만 구현)
class Dog : public BasicAnimalActions {
public:
    void eat() override {
        std::cout << "개가 먹이를 먹고 있습니다." << std::endl;
    }

    void sleep() override {
        std::cout << "개가 잠을 자고 있습니다." << std::endl;
    }
};

// 메인 함수 - ISP 데모
int main() {
    Bird bird;
    Fish fish;
    Dog dog;

    // 공통 행동 실행
    bird.eat();
    bird.sleep();

    // 날 수 있는지 확인 후 실행 (C++에서는 dynamic_cast 사용)
    FlyingAnimalActions* flyingBird = dynamic_cast<FlyingAnimalActions*>(&bird);
    if (flyingBird) {
        flyingBird->fly();
    }

    fish.eat();
    fish.sleep();

    // 수영할 수 있는지 확인 후 실행
    SwimmingAnimalActions* swimmingFish = dynamic_cast<SwimmingAnimalActions*>(&fish);
    if (swimmingFish) {
        swimmingFish->swim();
    }

    dog.eat();
    dog.sleep();

    return 0;
}
