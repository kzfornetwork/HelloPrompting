#include <iostream>
#include <string>
#include <memory>

// 추상화: MessageService
class MessageService {
public:
    virtual ~MessageService() = default;
    virtual void sendMessage(const std::string& message, const std::string& recipient) = 0;
};

// 구체적인 구현 1: Email 서비스
class EmailService : public MessageService {
public:
    void sendMessage(const std::string& message, const std::string& recipient) override {
        std::cout << "이메일을 " << recipient << "에게 전송: " << message << std::endl;
    }
};

// 구체적인 구현 2: SMS 서비스
class SMSService : public MessageService {
public:
    void sendMessage(const std::string& message, const std::string& recipient) override {
        std::cout << "SMS를 " << recipient << "에게 전송: " << message << std::endl;
    }
};

// 상위 모듈: Notification
class Notification {
private:
    std::unique_ptr<MessageService> messageService;

public:
    // 의존성 주입 (생성자 주입)
    Notification(std::unique_ptr<MessageService> service)
        : messageService(std::move(service)) {}

    void notifyUser(const std::string& message, const std::string& recipient) {
        messageService->sendMessage(message, recipient);
    }
};

// 메인 함수 - DIP 데모
int main() {
    // EmailService를 사용하는 경우
    auto emailService = std::make_unique<EmailService>();
    Notification emailNotification(std::move(emailService));
    emailNotification.notifyUser("이메일로 전송된 메시지입니다!", "john@example.com");

    // SMSService를 사용하는 경우
    auto smsService = std::make_unique<SMSService>();
    Notification smsNotification(std::move(smsService));
    smsNotification.notifyUser("SMS로 전송된 메시지입니다!", "010-1234-5678");

    return 0;
}
