#include <iostream>
#include <memory>

// 인터페이스: 날 수 있는 새
class Flyable {
public:
    virtual ~Flyable() = default;
    virtual void fly() = 0;
};

// 상위 클래스: Bird
class Bird {
public:
    virtual ~Bird() = default;

    void eat() {
        std::cout << "새가 먹이를 먹고 있습니다!" << std::endl;
    }
};

// 하위 클래스: Sparrow (날 수 있음)
class Sparrow : public Bird, public Flyable {
public:
    void fly() override {
        std::cout << "참새가 날고 있습니다!" << std::endl;
    }
};

// 하위 클래스: Ostrich (날 수 없음)
class Ostrich : public Bird {
    // fly() 메서드를 구현하지 않음
};

// 헬퍼 함수
void makeBirdEat(Bird& bird) {
    bird.eat();
}

void makeBirdFly(Flyable& bird) {
    bird.fly();
}

// 메인 함수 - LSP 준수
int main() {
    Sparrow sparrow;
    Ostrich ostrich;

    // 모든 새는 먹이를 먹을 수 있음
    makeBirdEat(sparrow);
    makeBirdEat(ostrich);

    // 날 수 있는 새만 Flyable 인터페이스를 사용
    makeBirdFly(sparrow);

    return 0;
}
