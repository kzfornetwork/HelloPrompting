#include <iostream>
#include <stdexcept>
#include <memory>

// 상위 클래스: Bird
class Bird {
public:
    virtual ~Bird() = default;

    virtual void fly() {
        std::cout << "새가 날고 있습니다!" << std::endl;
    }
};

// 하위 클래스: Sparrow (정상 동작)
class Sparrow : public Bird {
public:
    void fly() override {
        std::cout << "참새가 날고 있습니다!" << std::endl;
    }
};

// 하위 클래스: Ostrich (날 수 없지만 fly 메서드 상속됨)
class Ostrich : public Bird {
public:
    void fly() override {
        throw std::runtime_error("타조는 날 수 없습니다!");
    }
};

// 헬퍼 함수
void makeBirdFly(Bird& bird) {
    bird.fly();
}

// 메인 함수 - LSP 위반
int main() {
    Sparrow sparrow;
    Ostrich ostrich; // 타조는 Bird 타입으로 사용될 수 있음

    makeBirdFly(sparrow); // 정상 출력

    try {
        makeBirdFly(ostrich); // Runtime Exception 발생!
    } catch (const std::runtime_error& e) {
        std::cerr << "예외 발생: " << e.what() << std::endl;
    }

    return 0;
}
